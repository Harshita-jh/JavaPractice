package poly;

public class Main {

	public static void main(String[] args) {
		Person person = new Person();
		person.showDetail();
		
	}

}
