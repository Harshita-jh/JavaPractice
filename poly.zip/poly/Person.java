package poly;

public class Person {public void showDetail() {
	System.out.println("Basic details of Person");
}
}
