package poly;

public class Emp extends Person {
	public void showDetail() {
		System.out.println("Showing the details of the employee");
	}

}
